const string ALUNO_PATH = "data\\aluno.b",			
			 LIVRO_PATH = "data\\livro.b",	    	
			 EMP_PATH   = "data\\emp.b";		   

const int    STRSIZE    = 45,					    
			 FRAME		= 6,                        
			 TEXT		= 10;	                    

#define BDH 205 
#define BDV 186	

#define CSD 187 
#define CSE 201 
#define CID 188 
#define CIE 200 

#define JTE 204 
#define JTD 185 
#define JTS 203 
#define JTI 202 

#define JCQ 206 

#define cced 135
#define atil 198

